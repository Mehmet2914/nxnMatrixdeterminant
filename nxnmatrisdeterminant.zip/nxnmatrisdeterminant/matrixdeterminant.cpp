// Mehmet MUTLU - 20130855031 - Elektrik/elektronik m�hendisli�i - 2. ��retim

#include <stdio.h>
#include <stdlib.h>
int** matrix[5]; // Matrisleri point eden pointerlar� tutacaz. 

/* her matrisin satir ve sutun say�s�n� bir art�yorum.Her matris beraberinde sat�r ve sutun say�s�n� da tas�s�n diye
 sadece tek satir eklemek yeterl� olabilirdi.Ancak matrisler aras�ndaki islemlerin uygulanabilirli�i i�in
 satir ve sutun sayilarini 1 den baslatmam�z daha uygun
 art�r�mdan sonra bellek ay�r�yor
 sonra da satir ve sutun bilgilerini [0][0] ve [0][1] sakliyor. */
int** yerayirma(int, int);
// Yap�lacak her islem sonras�nda ya da hata durumlar�nda ayr�lan haf�zay� serbest b�rakmak icin
void matrisekran();
 
// baslang�c degeri integer olarak verilen matrisi, matris yap�s�nda ekrana yaz�yor.
void matrisyazma(int**);
 
// Ba�lang�c noktas� verilen matrisin elemanlar�n� kullan�c�dan al�yor
// boyutlar� zaten matrisin icindeki for dongusunun s�n�rlar�na dikkat edilmeli!
void matrisalma(int**);
 
// Yap�lacak i�lem icin gereken matris sayisi parametre olarak al�n�yor
// fonksiyon i�erisinde matris icin yer ay�r�m� ve matris degerlerini almak 
// icin di�er fonksiyonlar da cagiriliyor
void matrisbuyuklugu(int);
// matris boyutunun hesaplandigi fonksiyon
int determinant(int** , int );
// determinant hesabinin yapildigi fonksiyon
int main()
{	printf("\t\tDeterminant hesabi icin matris kare olmalidir");
	//1 adet matris datas� al
    matrisbuyuklugu(1);	
	//Kare matris olup olmad���n� kontrol et
	if( matrix[0][0][0] != matrix[0][0][1] ){
		printf("HATA : determinant�n�n alinmas� icin kare matris olmal�! \n");
	return 0;
	}
	//Determinant fonksiyonuna git ve matrisin determinant�n� hesaplay�p ekrana yaz. 
	printf("Determinant : |A| : %d \n", determinant(matrix[0],0));
    return 0;
}

void matrisbuyuklugu(int Matrisnumarasi){
	int i;
	int satir,sutun;
	
	for( i=0; i<Matrisnumarasi; i++ ){
		//Matrisin sat�r ve s�tun say�s�n� al
		printf("\n%d.Matrisin Satir Sayisi > ", i+1);
		scanf("%d", &satir);
		printf("\n%d.Matrisin Sutun Sayisi > ", i+1);
		scanf("%d", &sutun);
		// Olu�turulacak matris i�in memory'de haf�za ayir ve ayrilan memory'nin ilk adresi bu fonksiyondan d�ner.
		matrix[i] = yerayirma(satir, sutun);
		// Matris elemanlar�n�n de�erini kullan�c�dan alan fonksiyona matris i�in ayr�lan hafizanin ilk adresini g�nder.
		matrisalma(matrix[i]);
		
		printf("\n%d.Matris : \n", i+1);
		//De�erleri girilen matrisi ekrana yaz
		matrisyazma(matrix[i]);
	}
}

void matrisyazma(int** Matris){
	// dizimizi matris seklinde ekrana yazmaya yarayan fonksiyon
	int i,j;
	
	for( i=1; i<Matris[0][0]; i++ ){
		printf("\n");
		for( j=1; j<Matris[0][1]; j++ ){
			printf(" %2d", Matris[i][j]);
		}
	}
	printf("\n\n");
}

void matrisalma(int** Matris){
	// girilen satir ve sutun degerlerini bilgisayarin matris seklinde almasini saglayan fonksiyon
	int i,j;
	
	printf("\n");
	for( i=1; i<Matris[0][0]; i++ ){
		for( j=1; j<Matris[0][1]; j++ ){
			printf("[%d][%d] element : ", i,j);
			scanf("%d", &Matris[i][j]);
		}
	}
}

int** yerayirma(int satir, int sutun){
	int i;
	int **matrixPointer;
	
	// ilk satirda matrislerin boyutlar�n� sakl�yor
	satir++;
	sutun++;
	
	// Matris icin hafiza ayirma
	
	matrixPointer = (int**)malloc( satir * sizeof(int*) );
	//Kontrol		
	if( matrixPointer == NULL){ printf("HATA : Gerekli alan ayr�lamadi!."); exit(0); }
	
	for( i=0; i<satir; i++ ){
		matrixPointer[i] = (int*)malloc( sutun * sizeof(int) );
		// Kontrol
		if( matrixPointer[i] == NULL){ printf("HATA : Gerekli alan ayr�lamadi!."); exit(0); }
	}
	// malloc komutunu bilgisayarin bizim icin hafiza ayirmasi ve onu bosaltmasi icin kullandim
	// size of (int) durumuyla ise bize hafizadan bir integerlik alan ayirmasi icin kullandim
	// Eger isletim sisteminde yer ayrilamacak durumda ise program patlamamasi icin exit kullandik
	// Matrisin sat�r ve s�t�n bilgisini ilk sat�rda sakla
	matrixPointer[0][0] = satir;
	matrixPointer[0][1] = sutun;
	
	return matrixPointer;
}
 
int determinant(int** Matris, int derinlik){
	int det=0,isaret= -1;
	int newSat,newSut=1;
	int sut,sat,i,j;
	
	// base case
	if( Matris[0][0] == 3 ){
		// 2x2 l�k matrisin determinant�
		det = Matris[1][1] * Matris[2][2] - Matris[2][1] * Matris[1][2]; // det = a*d - c*b
		return det;
	}else{ // recursive durumu		
		// Determimant fonksiyonu islemlerini anlamak icin asagidaki link yararli olabilir
		// http://bilgisayarkavramlari.sadievrenseker.com/2012/05/01/matrisin-determinanti-matrix-determinant/
		// Determinant� birinci satira g�re alalim	
		sat = 1;
		
		// Alt matrislerin tutulacag� bolgelerin alikasyonu
		derinlik++; 
		// 3x3luk matriste 2x2l�k alt matrisler olusur, bir de yer ayirma fonk. art�r�mdan dolay� -1 = -2
		matrix[derinlik] = yerayirma(Matris[0][0]-2,Matris[0][1]-2); 
		
		
		for( sut=1; sut<Matris[0][1]; sut++ ){ // ilk satirdaki elemanlar�n s�ras�yla islenmesi
			newSat=0; // Alt matrislerin satir sayisi			
			// Ana matristen alt matrislerin olusturulmas�
			for( i=2; i<Matris[0][0]; i++ ){ // Det. birinci satire g�re al�nd�g� �c�n 2 den basla			
				newSat++; 
				newSut = 1; // Ayn� alt matris icin bir sonraki satir
				for( j=1; j<Matris[0][1]; j++ ){
					if( sut == j ){
						continue; // det al�nan sat�rdaki elemanlar�n sutunlar�n �st� ciziliyor.Alt matrise katm�yoruz.
					}
					matrix[derinlik][newSat][newSut] = Matris[i][j]; // Ana matristen alt matrisine eleman aktar�m�
					newSut++;
				}
			}
		
			det = det + Matris[sat][sut] * isaret * determinant(matrix[derinlik], derinlik);	// recursive fonksiyonu cagiriyoruz		
			isaret = isaret * (-1); // bir art� bir eksi olacak. (-1) uzeri i+J kuralindan kaynaklaniyor
					
		} // Determinant aldi�imiz satirin elemanlar�n� donderen for un sonu
		return det;	
	} // matris boyutunu kontrol eden if in sonu
}
	void matrisekran(){
	int i;
	
	for(i=0; i<5; i++){
		(matrix[i]);
	}
}
